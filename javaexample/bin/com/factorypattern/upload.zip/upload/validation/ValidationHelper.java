package com.factorypattern.upload.validation;

public class ValidationHelper {

	public static final String SYNTACTICAL_CHECK = "Syntactical_check";
	public static final String SEMANTICAL_CHECK = "Semantical_check";
}
