package com.factorypattern.upload.validation;

import java.util.List;

public abstract class SyntacticalCheck implements Validator{

	@Override
	public String getValidationType() {
		return ValidationHelper.SYNTACTICAL_CHECK;
	}
}
