package com.factorypattern.upload.validation;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ValidationService {

	public static Map<String, List<Validator>> mapValidator = new HashMap<>(); 
	
	static {
		List<Validator> syntacticalValidators = Arrays.asList(new PhotoValidator());
		mapValidator.put(ValidationHelper.SYNTACTICAL_CHECK, syntacticalValidators);
	}
	
}
