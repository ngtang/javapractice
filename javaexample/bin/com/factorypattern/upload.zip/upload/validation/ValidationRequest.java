package com.factorypattern.upload.validation;

import java.util.Set;
import java.util.TreeSet;

import com.factorypattern.upload.attachment.Attachment;

public class ValidationRequest {

	private Set<Attachment> attachments = new TreeSet<>();

	public Set<Attachment> getAttachments() {
		return attachments;
	}
}
