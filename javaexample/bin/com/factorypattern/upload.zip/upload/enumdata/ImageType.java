package com.factorypattern.upload.enumdata;

public enum ImageType {
	RAW, HD
}
